using InboundDocs.BlazorServer.Components;
using InboundDocs.BlazorServer.Services;
using InboundDocs.Core.Services;
using InboundDocs.Core.ViewModels;

var builder = WebApplication.CreateBuilder(args);

// Razor Components + Interactive Server (Blazor Server, .NET 8)
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// Domain services from InboundDocs.Core (registered as Scoped — per-circuit).
// See Section 4.3 of the article: "Stick with Scoped unless you have a deliberate reason not to."
builder.Services.AddScoped<IInboundDocumentRepository, InMemoryInboundDocumentRepository>();
builder.Services.AddScoped<InboundDocumentViewModel>();

// Dialog service: see Section 4.7. Double registration is intentional:
// - the concrete BlazorDialogService is shared with the DialogHost component (which subscribes to its event)
// - the IDialogService abstraction is what the ViewModel depends on.
builder.Services.AddScoped<BlazorDialogService>();
builder.Services.AddScoped<IDialogService>(sp => sp.GetRequiredService<BlazorDialogService>());

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
