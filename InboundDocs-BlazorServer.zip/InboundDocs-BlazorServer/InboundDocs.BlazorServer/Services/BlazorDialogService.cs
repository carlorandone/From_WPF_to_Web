using InboundDocs.Core.Services;

namespace InboundDocs.BlazorServer.Services;

public enum DialogKind { Info, Confirm }

public record DialogRequest(
    string Title,
    string Message,
    DialogKind Kind,
    TaskCompletionSource<DialogResult> Completion);

public class BlazorDialogService : IDialogService
{
    public event Action<DialogRequest>? OnRequest;

    public Task<DialogResult> ShowConfirmAsync(string title, string message)
    {
        var tcs = new TaskCompletionSource<DialogResult>();
        OnRequest?.Invoke(new DialogRequest(title, message, DialogKind.Confirm, tcs));
        return tcs.Task;
    }

    public Task ShowInfoAsync(string title, string message)
    {
        var tcs = new TaskCompletionSource<DialogResult>();
        OnRequest?.Invoke(new DialogRequest(title, message, DialogKind.Info, tcs));
        return tcs.Task;
    }
}
