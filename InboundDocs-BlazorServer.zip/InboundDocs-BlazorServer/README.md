# InboundDocs.BlazorServer — Project 2 (Blazor Server Migration)

This is **Project 2** of the three-project series from the article
**"From WPF to the Web: Reusing Your MVVM Investment in Blazor Server and React SPAs"**
by Carlo Randone, IBM Consulting, 2026.

It demonstrates the **Blazor Server migration** of the same `InboundDocs.Core` library that
powered the WPF host in Project 1 — with **zero changes** to Models, Services, or ViewModels.

## Architecture
- **InboundDocs.Core** — shared library (Models + Services + ViewModels).
  **IDENTICAL bit-for-bit** to the one in Project 1 — this is the article's central claim
  (Section 4.3): *"this class compiles and runs unchanged in a Blazor Server project."*
- **InboundDocs.BlazorServer** — Blazor Server host (.NET 8), with:
  - `Program.cs` registering the ViewModel as `Scoped` (per-circuit) — Section 4.3
  - `CascadingValue` pattern to share the ViewModel across child components — Section 4.5
  - `BlazorDialogService` + `DialogHost.razor` — Section 4.7
  - Explicit subscribe-in-`OnInitialized` / unsubscribe-in-`Dispose` — Section 4.3 + 7.4
  - `InvokeAsync(StateHasChanged)` defensive routing — Section 7.3
- **InboundDocs.Core.Tests** — same 6 xUnit tests as Project 1, **bit-for-bit identical**
  (the article's claim in Section 6.2: *"Unit tests of Core survive 100% in both scenarios"*).

## How to run
Requires .NET 8 SDK.

```
dotnet restore
dotnet build
dotnet run --project InboundDocs.BlazorServer
```

Then open `https://localhost:5001` (or `http://localhost:5000`) in your browser.

## How to test
```
dotnet test
```

## Sample data
The in-memory repository is pre-seeded with two documents (`R-12345`, `R-12346`).
Try the URL `/inbound-document/R-12345` to preload an existing document via deep link
(Section 6.1: "load-by-code mode").

## What was added compared to Project 1

| Project 1 (WPF) | Project 2 (Blazor Server) |
|---|---|
| `WpfDialogService.cs` (MessageBox) | `BlazorDialogService.cs` (TaskCompletionSource) + `DialogHost.razor` |
| `App.xaml` / `MainWindow.xaml` | `App.razor` / `MainLayout.razor` |
| `Views/InboundDocumentView.xaml` | `Pages/InboundDocumentPage.razor` + 3 child components under `Shared/` |
| Composition root inline in code-behind | `Program.cs` with `AddRazorComponents().AddInteractiveServerComponents()` |
| Direct `DataContext = new InboundDocumentViewModel(...)` | `[Inject]` + `CascadingValue` pattern |
| Implicit binding refresh from WPF engine | Explicit `PropertyChanged` subscription + `InvokeAsync(StateHasChanged)` |

## What did NOT change
- `InboundDocs.Core/Models/*.cs` — identical
- `InboundDocs.Core/Services/*.cs` — identical (including `IDialogService` abstraction!)
- `InboundDocs.Core/ViewModels/*.cs` — identical
- `InboundDocs.Core.Tests/*.cs` — identical

This is the central point of the article: the same C# ViewModel that the WPF host consumed
now drives a Razor component, with zero edits.

## Next step
**Project 3** (`InboundDocs-ReactSpa.zip`) — same `InboundDocs.Core` Models + Services exposed
via ASP.NET Core Minimal API, consumed by a Vite-based React SPA. The ViewModel layer is
reimplemented in TypeScript as a custom hook.
