using FluentAssertions;
using FluentAssertions.Events;
using InboundDocs.Core.Models;
using InboundDocs.Core.Services;
using InboundDocs.Core.ViewModels;
using Moq;
using Xunit;

namespace InboundDocs.Core.Tests;

// These tests run unchanged in Project 2 (Blazor Server) and Project 3 (React + API),
// because the ViewModel under test is platform-independent.
public class InboundDocumentViewModelTests
{
    private static InboundDocumentViewModel NewViewModel(
        Mock<IDialogService>? dialog = null,
        Mock<IInboundDocumentRepository>? repository = null)
    {
        dialog ??= new Mock<IDialogService>();
        repository ??= new Mock<IInboundDocumentRepository>();
        return new InboundDocumentViewModel(dialog.Object, repository.Object);
    }

    [Fact]
    public void Setting_ReceiptCode_raises_PropertyChanged()
    {
        var vm = NewViewModel();
        using var monitored = vm.Monitor();

        vm.ReceiptCode = "R-12345";

        monitored.Should().RaisePropertyChangeFor(x => x.ReceiptCode);
    }

    [Fact]
    public void CanSave_is_false_when_receipt_code_is_missing()
    {
        var vm = NewViewModel();
        vm.SupplierCode = "SUP-001";
        vm.ReceiptCode = "";

        vm.CanSave.Should().BeFalse();
    }

    [Fact]
    public void CanSave_is_true_when_both_codes_are_present()
    {
        var vm = NewViewModel();
        vm.ReceiptCode = "R-12345";
        vm.SupplierCode = "SUP-001";

        vm.CanSave.Should().BeTrue();
    }

    [Fact]
    public async Task SaveAsync_asks_for_confirmation_when_document_already_exists()
    {
        var dialog = new Mock<IDialogService>();
        dialog.Setup(d => d.ShowConfirmAsync(It.IsAny<string>(), It.IsAny<string>()))
              .ReturnsAsync(DialogResult.No);

        var repository = new Mock<IInboundDocumentRepository>();
        repository.Setup(r => r.FindByCodeAsync("R-12345"))
                  .ReturnsAsync(new InboundDocument { ReceiptCode = "R-12345" });

        var vm = NewViewModel(dialog, repository);
        vm.ReceiptCode = "R-12345";
        vm.SupplierCode = "SUP-001";

        await vm.SaveAsync();

        dialog.Verify(d => d.ShowConfirmAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        repository.Verify(r => r.SaveAsync(It.IsAny<InboundDocument>()), Times.Never);
    }

    [Fact]
    public async Task SaveAsync_persists_when_confirmation_is_yes()
    {
        var dialog = new Mock<IDialogService>();
        dialog.Setup(d => d.ShowConfirmAsync(It.IsAny<string>(), It.IsAny<string>()))
              .ReturnsAsync(DialogResult.Yes);

        var repository = new Mock<IInboundDocumentRepository>();
        repository.Setup(r => r.FindByCodeAsync("R-12345"))
                  .ReturnsAsync(new InboundDocument { ReceiptCode = "R-12345" });

        var vm = NewViewModel(dialog, repository);
        vm.ReceiptCode = "R-12345";
        vm.SupplierCode = "SUP-001";

        await vm.SaveAsync();

        repository.Verify(r => r.SaveAsync(It.IsAny<InboundDocument>()), Times.Once);
    }

    [Fact]
    public void RecomputeTotal_runs_when_a_line_is_added()
    {
        var vm = NewViewModel();
        vm.Lines.Add(new InboundDocumentLine { ItemCode = "X", Quantity = 2, UnitPrice = 50m });
        vm.Lines.Add(new InboundDocumentLine { ItemCode = "Y", Quantity = 3, UnitPrice = 25m });

        vm.TotalAmount.Should().Be(175m);
    }
}
