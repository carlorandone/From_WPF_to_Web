using System.ComponentModel.DataAnnotations;

namespace InboundDocs.Core.Models;

public class InboundDocument
{
    [Required(ErrorMessage = "Receipt code is required.")]
    [StringLength(20)]
    public string ReceiptCode { get; set; } = string.Empty;

    [Required(ErrorMessage = "Supplier code is required.")]
    [StringLength(20)]
    public string SupplierCode { get; set; } = string.Empty;

    [Required]
    public DateTime DocumentDate { get; set; } = DateTime.Today;

    [Range(0, double.MaxValue)]
    public decimal TotalAmount { get; set; }

    public List<InboundDocumentLine> Lines { get; set; } = new();
}
