using System.ComponentModel.DataAnnotations;

namespace InboundDocs.Core.Models;

public class InboundDocumentLine
{
    [Required]
    [StringLength(20)]
    public string ItemCode { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int Quantity { get; set; }

    [Range(0, double.MaxValue)]
    public decimal UnitPrice { get; set; }
}
