namespace InboundDocs.Core.Services;

public enum DialogResult { Ok, Cancel, Yes, No }

public interface IDialogService
{
    Task<DialogResult> ShowConfirmAsync(string title, string message);
    Task ShowInfoAsync(string title, string message);
}
