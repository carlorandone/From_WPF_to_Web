using InboundDocs.Core.Models;

namespace InboundDocs.Core.Services;

public interface IInboundDocumentRepository
{
    Task<InboundDocument?> FindByCodeAsync(string receiptCode);
    Task SaveAsync(InboundDocument document);
    Task<IReadOnlyList<InboundDocument>> ListAllAsync();
}
