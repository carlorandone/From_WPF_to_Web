using System.Collections.Concurrent;
using InboundDocs.Core.Models;

namespace InboundDocs.Core.Services;

/// <summary>
/// In-memory repository pre-seeded with two sample documents.
/// Thread-safe (uses ConcurrentDictionary) — safe for use as a Singleton in the API.
/// TODO: replace with EF Core / Dapper / HTTP client in production.
/// </summary>
public class InMemoryInboundDocumentRepository : IInboundDocumentRepository
{
    private readonly ConcurrentDictionary<string, InboundDocument> _store = new();

    public InMemoryInboundDocumentRepository()
    {
        _store["R-12345"] = new InboundDocument
        {
            ReceiptCode = "R-12345",
            SupplierCode = "SUP-001",
            DocumentDate = DateTime.Today.AddDays(-3),
            TotalAmount = 1250.00m,
            Lines = new()
            {
                new InboundDocumentLine { ItemCode = "ITM-100", Quantity = 10, UnitPrice = 50.00m },
                new InboundDocumentLine { ItemCode = "ITM-200", Quantity = 15, UnitPrice = 50.00m }
            }
        };

        _store["R-12346"] = new InboundDocument
        {
            ReceiptCode = "R-12346",
            SupplierCode = "SUP-002",
            DocumentDate = DateTime.Today.AddDays(-1),
            TotalAmount = 480.00m,
            Lines = new()
            {
                new InboundDocumentLine { ItemCode = "ITM-300", Quantity = 8, UnitPrice = 60.00m }
            }
        };
    }

    public Task<InboundDocument?> FindByCodeAsync(string receiptCode)
    {
        _store.TryGetValue(receiptCode, out var doc);
        return Task.FromResult(doc);
    }

    public Task SaveAsync(InboundDocument document)
    {
        _store[document.ReceiptCode] = document;
        return Task.CompletedTask;
    }

    public Task<IReadOnlyList<InboundDocument>> ListAllAsync()
        => Task.FromResult<IReadOnlyList<InboundDocument>>(_store.Values.ToList());
}