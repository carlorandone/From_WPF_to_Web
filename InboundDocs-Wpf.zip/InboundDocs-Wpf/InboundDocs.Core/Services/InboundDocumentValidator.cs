using System.ComponentModel.DataAnnotations;
using InboundDocs.Core.Models;

namespace InboundDocs.Core.Services;

public class DomainValidationResult
{
    public bool IsValid => Errors.Count == 0;
    public Dictionary<string, string[]> Errors { get; } = new();
    public Dictionary<string, string[]> AsDictionary() => Errors;
}

public class InboundDocumentValidator
{
    public DomainValidationResult Validate(InboundDocument document)
    {
        var result = new DomainValidationResult();
        var ctx = new ValidationContext(document);
        var errors = new List<ValidationResult>();

        if (!Validator.TryValidateObject(document, ctx, errors, validateAllProperties: true))
        {
            foreach (var e in errors)
            {
                var member = e.MemberNames.FirstOrDefault() ?? "Document";
                var msg = e.ErrorMessage ?? "Invalid";
                if (!result.Errors.ContainsKey(member))
                    result.Errors[member] = new[] { msg };
                else
                    result.Errors[member] = result.Errors[member].Append(msg).ToArray();
            }
        }
        return result;
    }
}
