using System.Collections.ObjectModel;
using System.Windows.Input;
using InboundDocs.Core.Models;
using InboundDocs.Core.Services;

namespace InboundDocs.Core.ViewModels;

// This class must remain platform-independent.
public class InboundDocumentViewModel : ViewModelBase
{
    private readonly IDialogService _dialog;
    private readonly IInboundDocumentRepository _repository;

    public InboundDocumentViewModel(IDialogService dialog, IInboundDocumentRepository repository)
    {
        _dialog = dialog;
        _repository = repository;

        SaveCommand = new RelayCommand(async _ => await SaveAsync(), _ => CanSave);
        AddLineCommand = new RelayCommand(_ => AddLine());
        LoadCommand = new RelayCommand(async p => await LoadAsync(p as string ?? string.Empty));

        Lines.CollectionChanged += (_, _) => RecomputeTotal();
    }

    private string _receiptCode = string.Empty;
    public string ReceiptCode
    {
        get => _receiptCode;
        set
        {
            if (SetProperty(ref _receiptCode, value))
                ((RelayCommand)SaveCommand).RaiseCanExecuteChanged();
        }
    }

    private string _supplierCode = string.Empty;
    public string SupplierCode
    {
        get => _supplierCode;
        set
        {
            if (SetProperty(ref _supplierCode, value))
                ((RelayCommand)SaveCommand).RaiseCanExecuteChanged();
        }
    }

    private DateTime _documentDate = DateTime.Today;
    public DateTime DocumentDate
    {
        get => _documentDate;
        set => SetProperty(ref _documentDate, value);
    }

    private decimal _totalAmount;
    public decimal TotalAmount
    {
        get => _totalAmount;
        private set => SetProperty(ref _totalAmount, value);
    }

    public ObservableCollection<InboundDocumentLine> Lines { get; } = new();

    public ICommand SaveCommand { get; }
    public ICommand AddLineCommand { get; }
    public ICommand LoadCommand { get; }

    public bool CanSave =>
        !string.IsNullOrWhiteSpace(ReceiptCode) &&
        !string.IsNullOrWhiteSpace(SupplierCode) &&
        !IsSaving;

    private bool _isSaving;
    public bool IsSaving
    {
        get => _isSaving;
        private set
        {
            if (SetProperty(ref _isSaving, value))
                ((RelayCommand)SaveCommand).RaiseCanExecuteChanged();
        }
    }

    public async Task SaveAsync()
    {
        if (!CanSave) return;

        var existing = await _repository.FindByCodeAsync(ReceiptCode);
        if (existing != null)
        {
            var result = await _dialog.ShowConfirmAsync(
                "Confirm",
                "A document with this receipt code already exists. Overwrite?");
            if (result != DialogResult.Yes) return;
        }

        IsSaving = true;
        try
        {
            await _repository.SaveAsync(ToModel());
            await _dialog.ShowInfoAsync("Saved", "The document was saved successfully.");
        }
        finally
        {
            IsSaving = false;
        }
    }

    public async Task LoadAsync(string receiptCode)
    {
        if (string.IsNullOrWhiteSpace(receiptCode)) return;
        var doc = await _repository.FindByCodeAsync(receiptCode);
        if (doc is null)
        {
            await _dialog.ShowInfoAsync("Not found", $"No document found with code '{receiptCode}'.");
            return;
        }
        ReceiptCode = doc.ReceiptCode;
        SupplierCode = doc.SupplierCode;
        DocumentDate = doc.DocumentDate;
        Lines.Clear();
        foreach (var l in doc.Lines) Lines.Add(l);
        RecomputeTotal();
    }

    private void AddLine()
    {
        Lines.Add(new InboundDocumentLine
        {
            ItemCode = $"ITM-{(Lines.Count + 1) * 100:D3}",
            Quantity = 1,
            UnitPrice = 0m
        });
    }

    private void RecomputeTotal()
        => TotalAmount = Lines.Sum(l => l.Quantity * l.UnitPrice);

    private InboundDocument ToModel() => new()
    {
        ReceiptCode = ReceiptCode,
        SupplierCode = SupplierCode,
        DocumentDate = DocumentDate,
        TotalAmount = TotalAmount,
        Lines = Lines.ToList()
    };
}
