using System.Windows;

namespace InboundDocs.Wpf;

public partial class App : Application
{
}
