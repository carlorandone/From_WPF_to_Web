using System.Windows;
using InboundDocs.Core.Services;
using CoreDialogResult = InboundDocs.Core.Services.DialogResult;

namespace InboundDocs.Wpf.Services;

public class WpfDialogService : IDialogService
{
    public Task<CoreDialogResult> ShowConfirmAsync(string title, string message)
    {
        var result = MessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Question);
        return Task.FromResult(result == MessageBoxResult.Yes ? CoreDialogResult.Yes : CoreDialogResult.No);
    }

    public Task ShowInfoAsync(string title, string message)
    {
        MessageBox.Show(message, title, MessageBoxButton.OK, MessageBoxImage.Information);
        return Task.CompletedTask;
    }
}
