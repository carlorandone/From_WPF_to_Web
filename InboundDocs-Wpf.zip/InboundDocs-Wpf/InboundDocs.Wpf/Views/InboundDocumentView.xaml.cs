using System.Windows.Controls;
using InboundDocs.Core.Services;
using InboundDocs.Core.ViewModels;
using InboundDocs.Wpf.Services;

namespace InboundDocs.Wpf.Views;

public partial class InboundDocumentView : UserControl
{
    public InboundDocumentView()
    {
        InitializeComponent();

        // Manual composition root.
        // In a larger app, use Microsoft.Extensions.DependencyInjection.
        IDialogService dialog = new WpfDialogService();
        IInboundDocumentRepository repository = new InMemoryInboundDocumentRepository();
        DataContext = new InboundDocumentViewModel(dialog, repository);
    }
}
