# InboundDocs.Wpf — Project 1 (WPF Traditional MVVM Baseline)

This is **Project 1** of the three-project series from the article  
**"From WPF to the Web: Reusing Your MVVM Investment in Blazor Server and React SPAs"**  
by Carlo Randone, IBM Consulting, 2026.

It is the **WPF "traditional" MVVM baseline** that will be evolved, in Projects 2 and 3, into a Blazor Server application and a React SPA, respectively, while reusing the `InboundDocs.Core` library across all three.

## Use case
A small **inbound documents form**: receipt code, supplier code, document date, total amount, lines.

## Architecture
- **InboundDocs.Core** — shared library (Models + Services + ViewModels). Knows nothing about WPF.
- **InboundDocs.Wpf** — WPF host (App.xaml, MainWindow, XAML View, WpfDialogService).
- **InboundDocs.Core.Tests** — xUnit tests proving the ViewModel is portable (these tests survive intact in Projects 2 and 3).

## MVVM flavor
Plain `INotifyPropertyChanged` + custom `RelayCommand` (Section 2.2 / 4.8 Flavor 1 of the article).  
No source generators, no NuGet beyond the BCL — the simplest possible baseline.

## Pre-migration cleanup already applied
- **`IDialogService` abstraction** is already in place (Section 7.1), so the ViewModel can be reused in Blazor and React without modification.
- **Validation via DataAnnotations** (Section 4.2), so the same Model works with Blazor's `EditForm` and with API-tier validation.

## How to run
Requires .NET 8 SDK + Windows.

```
dotnet restore
dotnet build
dotnet run --project InboundDocs.Wpf
```

## How to test
```
dotnet test
```

## Sample data
The in-memory repository is pre-seeded with two documents (`R-12345`, `R-12346`).  
Type `R-12345` as Receipt code and click Save to trigger the "document already exists" confirmation dialog.

## Next steps
- **Project 2** (`InboundDocs-BlazorServer.zip`) — same `InboundDocs.Core`, hosted by Blazor Server.
- **Project 3** (`InboundDocs-ReactSpa.zip`) — same `InboundDocs.Core` Models + Services exposed via ASP.NET Core Minimal API, consumed by a Vite-based React SPA.
